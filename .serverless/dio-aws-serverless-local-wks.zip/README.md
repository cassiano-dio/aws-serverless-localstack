# aws-serverless-localstack
Repositório de código para o workshop de desenvolvimento de aplicações serverless localmente utilizando AWS, Serverless Framework e Localstack com Docker.

- docker-compose up -d

- serverless deploy --stage local

- serverless invoke local -f createTable -l

